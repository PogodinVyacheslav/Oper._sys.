using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace Lab_8
{
    public partial class Form1:Form
    {
        public string fp="";
        public int c;
        public RegistryKey bk=RegistryKey.OpenBaseKey(RegistryHive.LocalMachine,RegistryView.Registry64);

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender,EventArgs e)
        {
            string[] kns=bk.GetSubKeyNames();
            foreach(string kn in kns)
            {
                listBox1.Items.Add(kn);
            }
        }

        private void listBox1_DoubleClick(object sender,EventArgs e)
        {
            string skn=listBox1.SelectedItem.ToString();
            if(fp=="")
            {
                fp+=skn;
            }
            else
            {
                fp+=@"\"+skn;
            }
            MessageBox.Show(fp);
            RegistryKey sk=bk.OpenSubKey(fp);
            string[] kns=sk.GetSubKeyNames();
            listBox1.Items.Clear();
            foreach(string kn in kns)
            {
                listBox1.Items.Add(kn);
            }
            listBox2.Items.Clear();
            c++;
        }

        private void listBox1_SelectedIndexChanged(object sender,EventArgs e)
        {
            try
            {
                string skn=listBox1.SelectedItem.ToString();
                string t;
                if(fp=="")
                {
                    t=skn;
                }
                else
                {
                    t=fp+@"\"+skn;
                }
                RegistryKey sk=bk.OpenSubKey(t);
                string[] vns=sk.GetValueNames();
                List<string> vs=new List<string>();
                foreach(string vn in vns)
                {
                    object v=sk.GetValue(vn);
                    if(v!=null)
                    {
                        vs.Add(vn+" - "+v.ToString());
                    }
                }
                listBox2.Items.Clear();
                listBox2.Items.AddRange(vs.ToArray());
            }
            catch{}
        }

        private void button1_Click(object sender,EventArgs e)
        {
            if(c>0)
            {
                if(fp.IndexOf(@"\",0)==-1)
                {
                    fp="";
                }
                string p=@"\\[^\\]*$";
                fp=Regex.Replace(fp,p,"");
                MessageBox.Show(fp);
                RegistryKey sk=bk.OpenSubKey(fp);
                string[] kns=sk.GetSubKeyNames();
                listBox1.Items.Clear();
                foreach(string kn in kns)
                {
                    listBox1.Items.Add(kn);
                }
                listBox2.Items.Clear();
                c--;
            }
        }

        private void button2_Click(object sender,EventArgs e)
        {
            if(textBox1.Text=="")
            {
                MessageBox.Show("Name of Key");
                return;
            }
            if(fp!="")
            {
                RegistryKey p=bk.OpenSubKey(fp,true);
                p.CreateSubKey(textBox1.Text);
            }
            else
            {
                bk.CreateSubKey(textBox1.Text);
            }
            RegistryKey sk=bk.OpenSubKey(fp);
            string[] kns=sk.GetSubKeyNames();
            listBox1.Items.Clear();
            foreach(string kn in kns)
            {
                listBox1.Items.Add(kn);
            }
        }

        private void button3_Click(object sender,EventArgs e)
        {
            string skn=listBox1.SelectedItem.ToString();
            string t;
            if(fp=="")
            {
                t=skn;
            }
            else
            {
                t=fp+@"\"+skn;
            }
            RegistryKey sk=bk.OpenSubKey(fp,true);
            sk.DeleteSubKey(skn);
            sk=bk.CreateSubKey(t);
            sk.SetValue(textBox2.Text,textBox3.Text);
            sk.Close();
        }

        private void button4_Click(object sender,EventArgs e)
        {
            string skn=listBox1.SelectedItem.ToString();
            RegistryKey p=bk.OpenSubKey(fp,true);
            p.DeleteSubKey(skn);
            RegistryKey sk=bk.OpenSubKey(fp);
            string[] kns=sk.GetSubKeyNames();
            listBox1.Items.Clear();
            foreach(string kn in kns)
            {
                listBox1.Items.Add(kn);
            }
        }

        private void button5_Click(object sender,EventArgs e)
        {
            string skn=listBox1.SelectedItem.ToString();
            string t;
            if(fp=="")
            {
                t=skn;
            }
            else
            {
                t=fp+@"\"+skn;
            }
            RegistryKey sk=bk.OpenSubKey(fp,true);
            sk.DeleteSubKey(skn);
            sk=bk.CreateSubKey(t);
            sk.Close();
        }
    }
}