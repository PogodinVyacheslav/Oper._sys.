﻿using Npgsql;
using System;
using System.Data;
using System.Windows.Forms;

namespace Lab._11._2
{
    public partial class Form1:Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender,EventArgs e)
        {
            string cs="Server=localhost;Port=5432;Database=Журнал;User Id=postgres;Password=Mqpz7Mqpz7;";
            try
            {
                string n=textBox1.Text;
                int c=Convert.ToInt32(textBox2.Text);
                string gn=textBox3.Text;
                int r=Convert.ToInt32(textBox4.Text);
                using(var cn=new NpgsqlConnection(cs))
                {
                    cn.Open();
                    using(var cd=new NpgsqlCommand())
                    {
                        cd.Connection=cn;
                        cd.CommandText="INSERT INTO study (name,course,group_name,rating) VALUES (@name,@course,@group_name,@rating)";
                        cd.Parameters.AddWithValue("name",n);
                        cd.Parameters.AddWithValue("course",c);
                        cd.Parameters.AddWithValue("group_name",gn);
                        cd.Parameters.AddWithValue("rating",r);
                        cd.ExecuteNonQuery();
                    }
                    MessageBox.Show("Сохран.");
                }
            }
            catch(NpgsqlException ex)
            {
                MessageBox.Show(string.Format("Ошиб. при сохран.: {0}",ex.Message));
            }
            catch(Exception ex)
            {
                MessageBox.Show(string.Format("Неизв. ошиб.: {0}",ex.Message));
            }
        }
        private void button2_Click(object sender,EventArgs e)
        {
            string cs="Server=localhost;Port=5432;Database=Журнал;User Id=postgres;Password=Mqpz7Mqpz7;";
            string sql="SELECT * FROM study";
            try
            {
                using(var cn=new NpgsqlConnection(cs))
                {
                    cn.Open();
                    using(var d=new NpgsqlDataAdapter(sql,cn))
                    {
                        DataTable dt=new DataTable();
                        d.Fill(dt);
                        dataGridView1.DataSource=dt;
                    }
                }
            }
            catch(NpgsqlException ex)
            {
                MessageBox.Show(string.Format("Ошиб. при получ.: {0}",ex.Message));
            }
            catch(Exception ex)
            {
                MessageBox.Show(string.Format("Неизв. ошиб.: {0}",ex.Message));
            }
        }
        private void button3_Click(object sender,EventArgs e)
        {
            string cs="Server=localhost;Port=5432;Database=Журнал;User Id=postgres;Password=Mqpz7Mqpz7;";
            string sql="TRUNCATE TABLE study";
            try
            {
                using(var cn=new NpgsqlConnection(cs))
                {
                    cn.Open();
                    using(var cd=new NpgsqlCommand(sql,cn))
                    {
                        cd.ExecuteNonQuery();
                    }
                    MessageBox.Show("Очищ.");
                }
            }
            catch(NpgsqlException ex)
            {
                MessageBox.Show(string.Format("Ошиб. при запр.: {0}",ex.Message));
            }
            catch(Exception ex)
            {
                MessageBox.Show(string.Format("Неизв. ошиб.: {0}",ex.Message));
            }
        }
    }
}
