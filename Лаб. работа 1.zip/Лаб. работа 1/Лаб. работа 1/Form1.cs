﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Лаб.работа_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_MouseHover(object sender, EventArgs e)
        {
            button1.Text = "пришёл";
            button2.Text = "ушёл";
        }

        private void button2_MouseHover(object sender, EventArgs e)
        {
            button2.Text = "пришёл";
            button1.Text = "ушёл";
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.Text = "";
            button2.Text = "";
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
            button2.Text = "";
            button1.Text = "";
        }

        private void button1_MouseClick(object sender, MouseEventArgs e)
        {
            Double a;
            a = Convert.ToDouble(textBox1.Text) * 2;
            textBox1.Text = Convert.ToString(a);
        }

        private void button2_MouseClick(object sender, MouseEventArgs e)
        {
            Double b;
            b = Convert.ToDouble(textBox1.Text) / 2;
            textBox1.Text = Convert.ToString(b);
        }
    }
}
