﻿using System;
using System.Threading;
using System.Windows.Forms;

namespace Лаб.работа_4
{
    public partial class Form1:Form
    {
        public Form1()
        {
            InitializeComponent();
            comboBox1.DataSource=Enum.GetValues(typeof(ThreadPriority));
        }

        public int C;
        public int S=0;
        public int M=0;
        public int H=0;
        public bool check=true;
        public ThreadPriority priority;

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void text()
        {
            try
            {
                while(check)
                {
                    C++;
                    this.textBox1.BeginInvoke((MethodInvoker)(()=>this.textBox1.Text=$"{C}"));
                    Thread.Sleep(100);
                    Thread T2=new Thread(timer);
                    button2.Tag=T2;
                }
            }
            catch(Exception){}
        }

        private void timer()
        {
            while(check)
            {
                S++;
                this.label3.BeginInvoke((MethodInvoker)(()=>this.label3.Text=Convert.ToString(S)));
                if (S==60)
                {
                    M++;
                    S=0;
                    this.label2.BeginInvoke((MethodInvoker)(()=>this.label2.Text=Convert.ToString(M)));
                }
                if (M==60)
                {
                    H++;
                    M=0;
                    this.label1.BeginInvoke((MethodInvoker)(()=>this.label1.Text=Convert.ToString(H)));
                }
                Thread.Sleep(1000);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Thread T1=new Thread(text);
            T1.Start();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            check=true;
            Thread V1=(Thread)button2.Tag;
            V1.Start();
            button3.Tag=V1;
            button4.Tag=V1;
            button5.Tag=V1;
            button2.Enabled=false;
            button3.Enabled=true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Thread V2=(Thread)button3.Tag;
            if (V2.ThreadState==ThreadState.Suspended)
            {
                V2.Resume();
            }
            else
            {
                V2.Suspend();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Thread V3=(Thread)button4.Tag;
            V3.Priority=priority;
            MessageBox.Show($"{V3.Priority}");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            check=false;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            ThreadPriority selectedState=(ThreadPriority)comboBox1.SelectedItem;
            priority=selectedState;
        }

    }
}
