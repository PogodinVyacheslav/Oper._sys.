﻿static void Main(string[] args)
{
    string fileName = "example.txt";
    string filePath = Path.Combine(Environment.CurrentDirectory, fileName);
    long freeSpaceBefore = DriveInfo.GetDrives()[0].AvailableFreeSpace;

    for (int i = 0; i < 3; i++)
    {
        string newFilePath = Path.Combine(Environment.CurrentDirectory, $"{i + 1}_{fileName}");
        File.Copy(filePath, newFilePath);
        long freeSpaceAfter = DriveInfo.GetDrives()[0].AvailableFreeSpace;
        Console.WriteLine("Free space before: {freeSpaceBefore}, Free space after: {freeSpaceAfter}");
        freeSpaceBefore = freeSpaceAfter;
    }
}
