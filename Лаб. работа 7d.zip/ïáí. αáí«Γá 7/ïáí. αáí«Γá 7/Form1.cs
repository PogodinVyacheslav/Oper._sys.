﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Threading;
using System.IO;
using System.Drawing;

namespace Лаб.работа_7
{
    public partial class Form1:Form
    {
        internal enum HT:int
        {
            JR=0,JP=1,
            KB=2,GM=3,
            CWP=4,CBT=5,
            SMF=6,M=7,
            H=8,D=9,
            S=10,FGI=11,
            CWPR=12,KL=13,
            ML=14
        }
        private struct P
        {
            public int x;
            public int y;
        }
        private struct MHS
        {
            public P pt;
            public uint md;
            public uint f;
            public uint t;
            public IntPtr ei;
        }
        private enum MM
        {
            LBD=0x0201,LBU=0x0202,
            MM=0x0200,MW=0x020A,
            RBD=0x0204,RBU=0x0205
        }
        private static string L="";
        private static Queue<string> fq=new Queue<string>();
        private static bool F=false;
        private Thread f=new Thread(()=>{});
        public int p=0;
        public static bool l=false;
        public static bool C=false;
        public static bool B=false;
        public static bool s=false;

        private delegate int HP(int nC,IntPtr wP,IntPtr lP);
        static HP Kh=new HP(KHP);
        static HP Mh=new HP(MHP);
        private static IntPtr MH=IntPtr.Zero;
        private static IntPtr KH=IntPtr.Zero;
        static HP hP=new HP(KHP);

        [DllImport("user32.dll")]
        static extern IntPtr SetWindowsHookEx(int ih,HP lf,IntPtr hm,uint TI);
        [DllImport("user32.dll")]
        static extern int CallNextHookEx(IntPtr hk,int nC,IntPtr wP,IntPtr lP);
        [DllImport("user32.dll")]
        static extern bool UnhookWindowsHookEx(IntPtr hk);
        [DllImport("kernel32.dll",CharSet=CharSet.Auto)]
        public static extern IntPtr GetModuleHandle(string MN);
        public const int KL=13;

        public Form1()
        {
            InitializeComponent();
            L=Directory.GetCurrentDirectory()+@"\log.txt";
            if(File.Exists(L))
            {
                File.Delete(L);
            }
            FileStream f1=new FileStream(L,FileMode.Create);
            f1.Seek(0,SeekOrigin.End);
            f1.Close();
            textBox1.ReadOnly=true;
        }

        private static IntPtr IH(int ID,HP fun)
        {
            IntPtr hI=GetModuleHandle("User32");
            return SetWindowsHookEx(ID,fun,hI,0);
        }

        public static int KHP(int nC,IntPtr wP,IntPtr lP)
        {
            if(nC>=0 && wP==(IntPtr)0x0100)
            {
                int KC=Marshal.ReadInt32(lP);
                if(l==true && KC==82)
                {
                    try
                    {
                        SendKeys.Send("lox");
                        return 1;
                    }
                    catch{}
                }
                if (C==true && (Keys)KC==Keys.C)
                {
                    try
                    {
                        Random c=new Random();
                        int cn=c.Next(97,123);
                        char cl=Convert.ToChar(cn);
                        string cs="{"+cl+"}";
                        SendKeys.Send(cs);
                        Thread.Sleep(100);
                        return 1;
                    }
                    catch{}
                }
                if(B==true && KC==66)
                {
                    return 1;
                }
                if(s==true && KC==83)
                {
                    for (;;)
                    {
                        Cursor.Position=new Point(0,0);
                    }
                }
                string op="Врем. событ.: ["+DateTime.Now.ToString()+"]"+Environment.NewLine+
                    "Наж. на кноп.: "+((Keys)KC).ToString()+Environment.NewLine;
                lock(fq)
                {
                    fq.Enqueue(op);
                }
            }
            return CallNextHookEx(KH,nC,wP,lP);
        }

        protected override void WndProc(ref Message m)
        {
            int DC=537;
            IntPtr flo=(IntPtr)32772;
            IntPtr fli=(IntPtr)32768;
            string O="";
            if(m.Msg==DC)
            {
                if(m.WParam==fli)
                    O="Врем. событ.: ["+DateTime.Now.ToString()+"]\nСобыт.: FLI\n";
                if(m.WParam==flo)
                    O="Врем. событ.: ["+DateTime.Now.ToString()+"]\nСобыт.: FLO\n";
                lock(fq)
                {
                    fq.Enqueue(O);
                }
            }
            base.WndProc(ref m);
        }

        public static int MHP(int nC,IntPtr wP,IntPtr lP)
        {
            if(nC>=0 && MM.MM != (MM)wP)
            {
                MHS MS=(MHS)Marshal.PtrToStructure(lP,typeof(MHS));
                string O="Врем. событ.: ["+DateTime.Now.ToString()+"]"+Environment.NewLine+
                    "Поз. мыши: [X:"+MS.pt.x.ToString()+",Y:"+MS.pt.y.ToString()+"] Событ.: "
                    +((MM)wP).ToString()+Environment.NewLine;
                lock(fq)
                {
                    fq.Enqueue(O);
                }
            }
            return CallNextHookEx(MH,nC,wP,lP);
        }

        private void sh()
        {
            f=new Thread(()=>
            {
                string e="";
                while(F)
                {
                    lock(fq)
                    {
                        if(fq.Count>0)
                        {
                            e=fq.Dequeue();
                            File.AppendAllText(L,e);
                            textBox1.BeginInvoke((MethodInvoker)(()=>textBox1.Text=""));
                            string[] gS=File.ReadAllLines(L);
                            string a="";
                            foreach(string gs in gS)
                            {
                                a=a+Environment.NewLine+gs+Environment.NewLine;
                            }
                            textBox1.BeginInvoke((MethodInvoker)(()=>textBox1.Text=a));
                        }
                    }
                }
            });
            F=true;
            f.Start();
            KH=IH((int)HT.KL,Kh);
            MH=IH((int)HT.ML,Mh);
        }

        private void eh()
        {
            if(MH!=IntPtr.Zero)
            {
                F=false;
                UnhookWindowsHookEx(KH);
                UnhookWindowsHookEx(MH);
                KH=IntPtr.Zero;
                MH=IntPtr.Zero;
            }
        }

        private void button1_Click(object sender,EventArgs e)
        {
            if(p==0)
            {
                sh(); button1.Text="Остановить"; p=1;
                textBox1.BeginInvoke((MethodInvoker)(()=>textBox1.Text=""));
                File.WriteAllText(L,string.Empty);
            }
            else
            {
                eh();
                button1.Text="Запустить";
                p=0;
            }
        }

        private void FC(object sender,FormClosingEventArgs e)
        {
            eh();
        }
        private void checkBox1_CheckedChanged(object sender,EventArgs e)
        {
            l=!l;
        }
        private void checkBox2_CheckedChanged(object sender,EventArgs e)
        {
            C=!C;
        }
        private void checkBox3_CheckedChanged(object sender,EventArgs e)
        {
            B=!B;
        }
        private void checkBox4_CheckedChanged(object sender,EventArgs e)
        {
            s=!s;
        }

    }
}
