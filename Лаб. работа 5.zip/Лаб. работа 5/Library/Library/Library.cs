﻿using System.Diagnostics;

namespace Library
{
    public class Library
    {
        public static string updateRAM()
        {
            Process[] processes = Process.GetProcesses();
            long memoryUse = 0;

            foreach (Process p in processes)
            {
                memoryUse += p.PagedMemorySize64 / (1024 * 1024);
            }

            return memoryUse.ToString() + " Mб";
        }

    }

}
