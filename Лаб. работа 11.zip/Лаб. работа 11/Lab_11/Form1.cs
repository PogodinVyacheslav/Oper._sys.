﻿using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace Lab_11
{
    public partial class Form1:Form
    {
        public Form1()
        {
            InitializeComponent();
            LP();
        }

        private void LP()
        {
            LBP.Items.Clear();
            string[] pf=Directory.GetFiles(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),"*.exe",SearchOption.AllDirectories);
            string[] pfx=Directory.GetFiles(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),"*.exe",SearchOption.AllDirectories);
            string[] p=A(pf,pfx);
            foreach(string pp in p)
            {
                LBP.Items.Add(Path.GetFileName(pp));
            }
        }

        private void BC(object sender,EventArgs e)
        {
            if(LBP.SelectedItem!=null)
            {
                string sp=LBP.SelectedItem.ToString();
                string pp=GPP(sp);
                if(!string.IsNullOrEmpty(pp))
                {
                    Thread t=new Thread(()=>PS(pp));
                    t.Start();
                }
                else
                {
                    MessageBox.Show("Ошиб. пути","Ошиб.",MessageBoxButtons.OK,MessageBoxIcon.Error);
                }
            }
        }

        private void PS(string pp)
        {
            try
            {
                Process.Start(pp);
            }
            catch(Exception ex)
            {
                MessageBox.Show($"Прог. ошиб.:{ex.Message}","Ошиб.",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private string GPP(string pn)
        {
            string[] pf=Directory.GetFiles(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),"*.exe",SearchOption.AllDirectories);
            string[] pfx=Directory.GetFiles(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),"*.exe",SearchOption.AllDirectories);
            string[] p=A(pf,pfx);
            foreach(string pp in p)
            {
                if(Path.GetFileName(pp)==pn)
                {
                    return pp;
                }
            }
            return null;
        }

        private T[] A<T>(T[] a1,T[] a2)
        {
            T[] a=new T[a1.Length+a2.Length];
            a1.CopyTo(a,0);
            a2.CopyTo(a,a1.Length);
            return a;
        }
    }
}
