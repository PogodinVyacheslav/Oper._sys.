﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace Лаб.работа_6
{
    public partial class Form1:Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public int x;
        public int y;
        public int cx;
        public int cy;
        public int w;
        public int h;
        public RECT rc=new RECT();
        public IntPtr wn;
        delegate bool EnumWindowsProc(IntPtr wn,IntPtr lp);

        [DllImport("user32.dll",SetLastError=true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool EnumWindows(EnumWindowsProc lef,IntPtr lp);
        [DllImport("user32.dll",SetLastError=true)]
        static extern int GetWindowText(IntPtr wn,StringBuilder ls,int nm);
        
        string GetWindowText(IntPtr wn)
        {
            int l=GetWindowTextLength(wn)+1;
            StringBuilder sb=new StringBuilder(l);
            l=GetWindowText(wn,sb,l);
            return sb.ToString(0,l);
        }

        [DllImport("user32.dll",SetLastError=true)]
        static extern int GetWindowTextLength(IntPtr wn);
        [DllImport("user32.dll",SetLastError=true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool IsWindowVisible(IntPtr wn);
        [DllImport("user32.dll",SetLastError=true)]
        static extern IntPtr FindWindow(string lcn,string lwn);
        [DllImport("user32.dll",SetLastError=true)]
        static extern int SetWindowText(IntPtr wn,string t);
        [DllImport("user32.dll",SetLastError=true)]
        static extern bool GetWindowRect(IntPtr wn,ref RECT lr);
        
        public struct RECT
        {
            public int Top;
            public int Left;
            public int Right;
            public int Bottom;
        }

        [DllImport("user32.dll",SetLastError=true)]
        static extern IntPtr SetWindowPos(IntPtr wn,IntPtr hwi,int X,int Y,int cx,int cy,uint uf);
        [DllImport("user32.dll",SetLastError=true)]
        static extern bool GetCursorPos(out POINT lpp);
        [StructLayout(LayoutKind.Sequential)]
        
        public struct POINT
        {
            public int X;
            public int Y;
        }

        public static POINT GetCursorPosition()
        {
            POINT lpp;
            GetCursorPos(out lpp);
            return lpp;
        }

        [DllImport("user32.dll",SetLastError=true)]
        static extern bool MoveWindow(IntPtr wn,int X,int Y,int W,int H,bool rp);
        System.Timers.Timer timer1;
        public delegate void InvokeDelegate();
        public string sl;

        private void filler()
        {
            listBox1.Items.Clear();
            EnumWindows((wn,lp)=>
            {
                if(IsWindowVisible(wn)&&GetWindowTextLength(wn)!=0)
                {
                    listBox1.Items.Add(GetWindowText(wn));
                }
                return true;
            },IntPtr.Zero);
        }

        private void EventFill(object sender,EventArgs e)
        {
            listBox1.BeginInvoke(new InvokeDelegate(filler));
        }

        private void EventText(object sender,EventArgs e)
        {
            SetWindowText(wn,textBox1.Text);
            sl=GetWindowText(wn);
        }

        private void Form1_Load(object sender,EventArgs e)
        {
            Size r=Screen.PrimaryScreen.Bounds.Size;
            timer1=new System.Timers.Timer();
            listBox1.Items.Clear();
            timer1.Interval=1000;
            timer1.Elapsed+=EventFill;
            timer1.Elapsed+=EventText;
            timer1.Start();
        }

        private void textBox2_TextChanged(object sender,EventArgs e)
        {
            try
            {
                cy=Convert.ToInt32(textBox2.Text);
            }
            catch(Exception){}
        }

        private void textBox3_TextChanged(object sender,EventArgs e)
        {
            try
            {
                cx=Convert.ToInt32(textBox3.Text);
            }
            catch(Exception){}
        }

        private void button1_Click(object sender,EventArgs e)
        {
            MoveWindow(wn,cx,cy,w,h,true);
            GetWindowRect(wn,ref rc);
            x=rc.Left;
            y=rc.Top;
        }

        private void hScrollBar1_ValueChanged(object sender,EventArgs e)
        {
            int H=h*hScrollBar1.Value;
            int W=w*hScrollBar1.Value;
            MoveWindow(wn,x,y,W,H,true);
            MessageBox.Show(hScrollBar1.Value.ToString());
        }

        private void listBox1_SelectedIndexChanged(object sender,EventArgs e)
        {
            if(listBox1.SelectedIndex!=-1)
            {
                wn=FindWindow(null,listBox1.SelectedItem.ToString());
                GetWindowRect(wn,ref rc);
                w=rc.Right-rc.Left;
                h=rc.Bottom-rc.Top;
                x=rc.Left;
                y=rc.Top;
                textBox1.Text=GetWindowText(wn);
            }
        }
    }
}

