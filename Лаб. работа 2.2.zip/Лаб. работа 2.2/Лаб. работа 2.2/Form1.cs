﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Лаб.работа_2._2
{
    public partial class Form1 : Form
    {
        private bool f_open, f_save;
       
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                label1.Text = openFileDialog1.FileName;
                f_open = true;
            }
            else
            {
                label1.Text = "None";
                f_open = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                label2.Text = saveFileDialog1.FileName;
                f_save = true;
            }
            else
            {
                label2.Text = "None";
                f_save = false;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!f_open || !f_save) return;

            FileStream fr = null;
            FileStream fw = null;

            int x;

            try
            {
                fr = new FileStream(openFileDialog1.FileName, FileMode.Open);
                fw = new FileStream(saveFileDialog1.FileName, FileMode.Create);

                x = fr.ReadByte();
                while (x != -1)
                {
                    fw.WriteByte((byte)x);
                    x = fr.ReadByte();
                }

                label3.Text = "Процесс завершён!";
            }
            catch (IOException exc)
            {
                label3.Text = exc.Message;
            }
            finally
            {
                if (fr != null) fr.Close();
                if (fw != null) fw.Close();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string text = richTextBox1.Text;
            MessageBox.Show(text);

            SaveFileDialog open = new SaveFileDialog();
            open.ShowDialog();
            string path = open.FileName;

            try
            {
                using (FileStream fs = File.Create(path))
                {
                    byte[] info = new UTF8Encoding(true).GetBytes(text);
                    fs.Write(info, 0, info.Length);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = "None";
            label2.Text = "None";
            label3.Text = "";
            f_open = false;
            f_save = false;
        }
    }
}
