﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Лаб.работа_1
{
    public partial class Form1:Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_MouseHover(object sender,EventArgs e)
        {
            button1.Text="пришёл";
            button2.Text="ушёл";
        }
        private void button2_MouseHover(object sender,EventArgs e)
        {
            button2.Text="пришёл";
            button1.Text="ушёл";
        }
        private void button3_MouseHover(object sender,EventArgs e)
        {
            button3.BackColor=Color.Red;
            button4.BackColor=Color.Blue;
        }
        private void button4_MouseHover(object sender,EventArgs e)
        {
            button4.BackColor=Color.Red;
            button3.BackColor=Color.Blue;
        }

        private void button1_MouseLeave(object sender,EventArgs e)
        {
            button1.Text="";
            button2.Text="";
        }
        private void button2_MouseLeave(object sender,EventArgs e)
        {
            button2.Text="";
            button1.Text="";
        }
        private void button3_MouseLeave(object sender,EventArgs e)
        {
            button3.BackColor=Color.White;
            button4.BackColor=Color.White;
        }
        private void button4_MouseLeave(object sender,EventArgs e)
        {
            button3.BackColor=Color.White;
            button4.BackColor=Color.White;
        }

        private void button1_MouseClick(object sender,MouseEventArgs e)
        {
            Double n=Convert.ToDouble(textBox2.Text);
            Double a=Convert.ToDouble(textBox1.Text)*n;
            textBox1.Text=Convert.ToString(a);
        }
        private void button2_MouseClick(object sender,MouseEventArgs e)
        {
            Double n=Convert.ToDouble(textBox2.Text);
            if(n==0)
                MessageBox.Show("Ошиб.");
            Double b=Convert.ToDouble(textBox1.Text)/n;
            textBox1.Text=Convert.ToString(b);
        }
        private void button3_Click(object sender,EventArgs e)
        {
            Double n=Convert.ToDouble(textBox2.Text);
            Double с=Math.Pow(Convert.ToDouble(textBox1.Text),n);
            textBox1.Text=Convert.ToString(с);
        }
        private void button4_Click(object sender,EventArgs e)
        {
            Double n=Convert.ToDouble(textBox2.Text);
            if(n==0)
                MessageBox.Show("Ошиб.");
            Double d=Math.Pow(Convert.ToDouble(textBox1.Text),1/n);
            textBox1.Text=Convert.ToString(d);
        }
    }
}
